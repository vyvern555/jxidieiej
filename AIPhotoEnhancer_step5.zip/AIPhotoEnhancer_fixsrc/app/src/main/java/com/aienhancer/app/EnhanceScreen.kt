package com.aienhancer.app

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.withContext
import kotlin.coroutines.coroutineContext
import kotlin.math.min
import kotlin.math.roundToInt

private const val SCALE = 4
private const val OVERLAP = 16

@Composable
fun EnhanceScreen(uri: Uri, onBack: () -> Unit) {
    val context = LocalContext.current

    var original by remember { mutableStateOf<Bitmap?>(null) }
    var enhanced by remember { mutableStateOf<Bitmap?>(null) }
    var progress by remember { mutableFloatStateOf(0f) }
    var error by remember { mutableStateOf<String?>(null) }
    var strength by remember { mutableFloatStateOf(1f) }
    var saving by remember { mutableStateOf(false) }
    var runId by remember { mutableIntStateOf(0) }
    var saveTrigger by remember { mutableIntStateOf(0) }

    // Загрузка фото + улучшение. Отменяется автоматически, если экран закрыли.
    LaunchedEffect(uri, runId) {
        error = null
        enhanced = null
        original = null
        progress = 0f
        try {
            val result = withContext(Dispatchers.Default) {
                val job = coroutineContext[Job]
                val src = ImageUtils.loadBitmap(context, uri, ImageUtils.maxInputSideFor(SCALE))
                original = src
                ONNXModelRunner(context).use { runner ->
                    ImageUtils.processInTiles(
                        source = src,
                        scale = runner.scale,
                        tileSize = runner.tileCore(OVERLAP),
                        overlap = OVERLAP,
                        onProgress = { progress = it }
                    ) { tile ->
                        job?.ensureActive()
                        runner.run(tile)
                    }
                }
            }
            enhanced = result
        } catch (e: CancellationException) {
            throw e
        } catch (e: OutOfMemoryError) {
            error = "Не хватило памяти. Попробуй фото поменьше."
        } catch (e: Throwable) {
            error = e.localizedMessage ?: e.javaClass.simpleName
        }
    }

    // Сохранение. Запускается через saveTrigger (в т.ч. после выдачи разрешения).
    LaunchedEffect(saveTrigger) {
        if (saveTrigger == 0) return@LaunchedEffect
        val o = original ?: return@LaunchedEffect
        val e = enhanced ?: return@LaunchedEffect
        saving = true
        try {
            val s = strength
            withContext(Dispatchers.Default) {
                val out = ImageUtils.blend(o, e, s)
                try {
                    saveToGallery(context, out)
                } finally {
                    out.recycle()
                }
            }
            Toast.makeText(context, "Сохранено в Pictures/AIPhotoEnhancer", Toast.LENGTH_LONG).show()
        } catch (ex: Throwable) {
            Toast.makeText(
                context,
                "Не удалось сохранить: ${ex.localizedMessage ?: ex.javaClass.simpleName}",
                Toast.LENGTH_LONG
            ).show()
        } finally {
            saving = false
        }
    }

    // На Android 8–9 для записи в галерею нужно разрешение
    val storagePermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) saveTrigger++
        else Toast.makeText(context, "Без разрешения сохранить нельзя", Toast.LENGTH_SHORT).show()
    }

    val onSave: () -> Unit = {
        val needPermission = Build.VERSION.SDK_INT < Build.VERSION_CODES.Q &&
            ContextCompat.checkSelfPermission(
                context, Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) != PackageManager.PERMISSION_GRANTED
        if (needPermission) storagePermission.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        else saveTrigger++
    }

    val orig = original
    val enh = enhanced
    val processing = error == null && enh == null

    Column(
        Modifier.fillMaxSize().background(Color.Black).systemBarsPadding(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            when {
                error != null -> Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(24.dp)
                ) {
                    Text("Не удалось улучшить фото", color = Color.White, fontSize = 18.sp)
                    Text(
                        error ?: "",
                        color = Color(0xFFBBBBBB),
                        fontSize = 13.sp,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                    Button(onClick = { runId++ }, modifier = Modifier.padding(top = 16.dp)) {
                        Text("Повторить")
                    }
                }
                orig != null -> BeforeAfter(orig, enh, strength)
                else -> Text("Открываю фото…", color = Color.White)
            }
        }

        if (processing && error == null && orig != null) {
            Text(
                "Улучшаю… ${(progress * 100).roundToInt()}%",
                color = Color.White,
                modifier = Modifier.padding(top = 8.dp)
            )
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 8.dp)
            )
        }

        if (enh != null) {
            Text(
                "Сила улучшения: ${(strength * 100).roundToInt()}%   •   ${enh.width} × ${enh.height}",
                color = Color.White,
                fontSize = 14.sp,
                modifier = Modifier.padding(top = 8.dp)
            )
            Slider(
                value = strength,
                onValueChange = { strength = it },
                modifier = Modifier.padding(horizontal = 24.dp)
            )
        }

        Row(
            Modifier.fillMaxWidth().padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedButton(onClick = onBack, modifier = Modifier.weight(1f)) {
                Text("Назад")
            }
            Button(
                onClick = onSave,
                enabled = enh != null && !saving,
                modifier = Modifier.weight(1f)
            ) {
                Text(if (saving) "Сохраняю…" else "Сохранить")
            }
        }
    }
}

/**
 * Сравнение До/После: слева оригинал, справа улучшенное (с учётом силы).
 * Разделитель можно двигать пальцем. Пока улучшенного нет — показывается только оригинал.
 */
@Composable
private fun BeforeAfter(original: Bitmap, enhanced: Bitmap?, strength: Float) {
    val origImage = remember(original) { original.asImageBitmap() }
    val enhImage = remember(enhanced) { enhanced?.asImageBitmap() }
    var divider by remember { mutableFloatStateOf(0.5f) }

    Box(Modifier.fillMaxSize()) {
        Canvas(
            Modifier
                .fillMaxSize()
                .pointerInput(enhImage) {
                    if (enhImage == null) return@pointerInput
                    detectHorizontalDragGestures(
                        onDragStart = { divider = (it.x / size.width).coerceIn(0f, 1f) }
                    ) { change, _ ->
                        divider = (change.position.x / size.width).coerceIn(0f, 1f)
                    }
                }
        ) {
            // Размер по пропорциям оригинала (улучшенное в 4 раза больше, пропорции те же)
            val iw = original.width.toFloat()
            val ih = original.height.toFloat()
            val fit = min(size.width / iw, size.height / ih)
            val dw = (iw * fit).roundToInt()
            val dh = (ih * fit).roundToInt()
            val dstOffset = IntOffset(
                ((size.width - dw) / 2f).roundToInt(),
                ((size.height - dh) / 2f).roundToInt()
            )
            val dstSize = IntSize(dw, dh)

            drawImage(
                image = origImage,
                dstOffset = dstOffset,
                dstSize = dstSize,
                filterQuality = FilterQuality.High
            )

            if (enhImage != null) {
                val splitX = size.width * divider
                clipRect(left = splitX, right = size.width) {
                    drawImage(
                        image = enhImage,
                        dstOffset = dstOffset,
                        dstSize = dstSize,
                        alpha = strength.coerceIn(0f, 1f),
                        filterQuality = FilterQuality.High
                    )
                }
                drawLine(
                    color = Color.White,
                    start = Offset(splitX, 0f),
                    end = Offset(splitX, size.height),
                    strokeWidth = 2.dp.toPx()
                )
                drawCircle(
                    color = Color.White,
                    radius = 14.dp.toPx(),
                    center = Offset(splitX, size.height / 2f)
                )
            }
        }

        if (enhImage != null) {
            Label("До", Modifier.align(Alignment.TopStart))
            Label("После", Modifier.align(Alignment.TopEnd))
        }
    }
}

@Composable
private fun Label(text: String, modifier: Modifier) {
    Box(
        modifier
            .padding(12.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0x99000000))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(text, color = Color.White, fontSize = 13.sp)
    }
}

/** Сохраняет Bitmap в Pictures/AIPhotoEnhancer как JPEG. */
private fun saveToGallery(context: Context, bitmap: Bitmap): Uri {
    val values = ContentValues().apply {
        put(MediaStore.Images.Media.DISPLAY_NAME, "enhanced_${System.currentTimeMillis()}.jpg")
        put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            put(
                MediaStore.Images.Media.RELATIVE_PATH,
                Environment.DIRECTORY_PICTURES + "/AIPhotoEnhancer"
            )
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
    }
    val resolver = context.contentResolver
    val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        ?: error("Галерея не приняла файл")
    try {
        val ok = resolver.openOutputStream(uri)?.use { bitmap.compress(Bitmap.CompressFormat.JPEG, 95, it) }
            ?: error("Не удалось открыть файл для записи")
        check(ok) { "Не удалось закодировать JPEG" }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            values.clear()
            values.put(MediaStore.Images.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
        }
    } catch (e: Throwable) {
        resolver.delete(uri, null, null)
        throw e
    }
    return uri
}
